
/*
 * A library for the message.
 */

#pragma once

#include <string>

#define MESSAGE_API

/*
 * Return the message.
 */
MESSAGE_API std::string get_message();

  